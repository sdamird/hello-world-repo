# sample-springboot
1. Build sample sping boot jar
  $ mvn package

2. Build Docker image
  $ docker build -t <Imagename> .

